//
//  ViewController.m
//  OCDemo
//
//  Created by wjq on 1/1/16.
//  Copyright © 2016 ioslearning. All rights reserved.
//

#import "ViewController.h"

typedef NS_ENUM(NSUInteger, kMovingDir)
{
    kMovingDirTop = 1,
    kMovingDirButtom,
    kMovingDirLeft,
    kMovingDirRight,
};

CGFloat const kMovingDelta = 50.0;      //移动系数
CGFloat const kZoomingDelta = 50.0;     //放大缩小系数

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *headImageView;   //可移动的按钮
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)move:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    CGPoint p = self.headImageView.center;
    switch (button.tag) {
        case kMovingDirTop: p.y -= kMovingDelta; break;  //往上移动
        case kMovingDirButtom: p.y += kMovingDelta; break;  //往下移动
        case kMovingDirLeft: p.x -= kMovingDelta; break; //往左移动
        case kMovingDirRight: p.x += kMovingDelta; break; //往右移动
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0];
    self.headImageView.center = p;
    [UIView commitAnimations];
}

- (IBAction)zoom:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    CGRect rect = self.headImageView.bounds;
    if (button.tag) {
        rect.size.width -= kZoomingDelta;
        rect.size.height -= kZoomingDelta;
    } else {
        rect.size.width += kZoomingDelta;
        rect.size.height += kZoomingDelta;
    }
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0];
    self.headImageView.bounds = rect;
    [UIView commitAnimations];
}

@end
