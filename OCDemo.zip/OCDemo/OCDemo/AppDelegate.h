//
//  AppDelegate.h
//  OCDemo
//
//  Created by wjq on 1/1/16.
//  Copyright © 2016 ioslearning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

