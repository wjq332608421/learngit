//
//  AppDelegate.h
//  Homepwner
//
//  Created by wjq on 10/16/15.
//  Copyright © 2015 ioslearning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

